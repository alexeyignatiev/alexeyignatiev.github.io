#!/usr/bin/env python
#-*- coding:utf-8 -*-
##
## qsolve.py
##
##  Created on: Dec 14, 2015
##      Author: Alessandro Previti, Alexey S. Ignatiev
##      E-mail: alessandro.previti@ucdconnect.ie, aignatiev@ciencias.ulisboa.pt
##

#
#==============================================================================
from pysmt.exceptions import SolverReturnedUnknownResultError
from pysmt.shortcuts import Bool, get_model, Not, Solver


#
#==============================================================================
def get_qmodel(x_univl, formula, maxiters=None, solver_name=None, verbose=False):
    """
        A simple 2QBF CEGAR implementation for SMT.
    """

    x_univl = set(x_univl)
    x_exist = formula.get_free_variables() - x_univl

    with Solver(name=solver_name) as asolver:
        asolver.add_assertion(Bool(True))
        iters = 0

        while maxiters is None or iters <= maxiters:
            iters += 1

            amodel = asolver.solve()
            if not amodel:
                return None
            else:
                cand = {v: asolver.get_value(v) for v in x_exist}
                subform = formula.substitute(cand).simplify()
                if verbose:
                    print 'c qsolve cand{0}: {1}'.format(iters, cand)

                cmodel = get_model(Not(subform), solver_name=solver_name)
                if cmodel is None:
                    return cand
                else:
                    coex = {v: cmodel[v] for v in x_univl}
                    subform = formula.substitute(coex).simplify()
                    if verbose:
                        print 'c qsolve coex{0}: {1}'.format(iters, coex)

                    asolver.add_assertion(subform)

        raise SolverReturnedUnknownResultError

