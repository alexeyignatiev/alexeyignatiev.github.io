from distutils.core import setup, Extension
import numpy.distutils.misc_util

hitman_pymodule = Extension('pyhitman',
        sources = [ 'py_hitman.cc' ],
        extra_compile_args = [ '-std=c++11', '-Wno-deprecated' ],
        include_dirs = [ '..', '../include' ],
        language = 'c++',
        libraries = [ 'hitman', 'stdc++' ],
        library_dirs = [ '..' ]
)

setup ( name = 'pyhitman',
        version = '1.0',
        description = 'A python wrapper around the hitman library',
        author = 'Alexey Ignatiev',
        author_email = 'aignatiev@ciencias.ulisboa.pt',
        ext_modules=[hitman_pymodule],
)
