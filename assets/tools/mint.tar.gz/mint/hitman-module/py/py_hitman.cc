/*
 * py_hitman.cc
 *
 *  Created on: Nov 30, 2015
 *      Author: Alexey S. Ignatiev
 *      E-mail: aignatiev@ciencias.ulisboa.pt
 */

#define PY_SSIZE_T_CLEAN

#include <stdio.h>
#include <Python.h>

#include "hit_minimal.hh"
#include "hit_minimum.hh"

using namespace std;

// docstrings
//=============================================================================
static char  module_docstring[] = "This module provides an interface for "
                                  "computing and enumerating minimal and "
                                  "minimum hitting sets.";
static char     new_docstring[] = "Create a new hitting set enumerator.";
static char     get_docstring[] = "Get a new hitting set.";
static char    enum_docstring[] = "Iterate through hitting sets one by one.";
static char     hit_docstring[] = "Hit argument set next time.";
static char   block_docstring[] = "Add an additional constraint to hitting "
                                  "set enumerator.";
static char   weigh_docstring[] = "Weigh elements of the sets and consider "
                                  " minimum weight hitting sets enumeration.";
static char    cost_docstring[] = "Show current cost.";
static char   clear_docstring[] = "Clear hitting set enumerator by removing "
                                  "all of its constraints.";
static char     del_docstring[] = "Delete object of hitting set enumerator.";
static char    trim_docstring[] = "Set how many trimming attemps to do.";
static char onecall_docstring[] = "Use one SAT call per hitting set";
static char    algo_docstring[] = "Choose MCS-based algorithm for doing "
                                  "hitting set enumeration (lbx, ucd, "
                                  "ubs, or lopz).";
static char   dcall_docstring[] = "Use clause D checks in MCS-based "
                                  "hitting set enumeration).";


// function declaration for functions available in module
//=============================================================================
extern "C" {
	static PyObject *py_hitminimum_new   (PyObject *, PyObject *);
	static PyObject *py_hitminimum_get   (PyObject *, PyObject *);
	static PyObject *py_hitminimum_enum  (PyObject *, PyObject *);
	static PyObject *py_hitminimum_hit   (PyObject *, PyObject *);
	static PyObject *py_hitminimum_block (PyObject *, PyObject *);
	static PyObject *py_hitminimum_weigh (PyObject *, PyObject *);
	static PyObject *py_hitminimum_cost  (PyObject *, PyObject *);
	static PyObject *py_hitminimum_clear (PyObject *, PyObject *);
	static PyObject *py_hitminimum_del   (PyObject *, PyObject *);
	static PyObject *py_hitminimum_trim  (PyObject *, PyObject *);
	static PyObject *py_hitminimum_1call (PyObject *, PyObject *);

	static PyObject *py_hitminimal_new   (PyObject *, PyObject *);
	static PyObject *py_hitminimal_get   (PyObject *, PyObject *);
	static PyObject *py_hitminimal_enum  (PyObject *, PyObject *);
	static PyObject *py_hitminimal_hit   (PyObject *, PyObject *);
	static PyObject *py_hitminimal_block (PyObject *, PyObject *);
	static PyObject *py_hitminimal_clear (PyObject *, PyObject *);
	static PyObject *py_hitminimal_del   (PyObject *, PyObject *);
	static PyObject *py_hitminimal_algo  (PyObject *, PyObject *);
	static PyObject *py_hitminimal_dcall (PyObject *, PyObject *);
}

// module specification
//=============================================================================
static PyMethodDef module_methods[] = {
	{ "hitminimum_new",   py_hitminimum_new,   METH_VARARGS,     new_docstring },
	{ "hitminimum_get",   py_hitminimum_get,   METH_VARARGS,     get_docstring },
	{ "hitminimum_enum",  py_hitminimum_enum,  METH_VARARGS,    enum_docstring },
	{ "hitminimum_hit",   py_hitminimum_hit,   METH_VARARGS,     hit_docstring },
	{ "hitminimum_block", py_hitminimum_block, METH_VARARGS,   block_docstring },
	{ "hitminimum_weigh", py_hitminimum_weigh, METH_VARARGS,   weigh_docstring },
	{ "hitminimum_cost",  py_hitminimum_cost,  METH_VARARGS,    cost_docstring },
	{ "hitminimum_clear", py_hitminimum_clear, METH_VARARGS,   clear_docstring },
	{ "hitminimum_del",   py_hitminimum_del,   METH_VARARGS,     del_docstring },
	{ "hitminimum_trim",  py_hitminimum_trim,  METH_VARARGS,    trim_docstring },
	{ "hitminimum_1call", py_hitminimum_1call, METH_VARARGS, onecall_docstring },

	{ "hitminimal_new",   py_hitminimal_new,   METH_VARARGS,     new_docstring },
	{ "hitminimal_get",   py_hitminimal_get,   METH_VARARGS,     get_docstring },
	{ "hitminimal_enum",  py_hitminimal_enum,  METH_VARARGS,    enum_docstring },
	{ "hitminimal_hit",   py_hitminimal_hit,   METH_VARARGS,     hit_docstring },
	{ "hitminimal_block", py_hitminimal_block, METH_VARARGS,   block_docstring },
	{ "hitminimal_clear", py_hitminimal_clear, METH_VARARGS,   clear_docstring },
	{ "hitminimal_del",   py_hitminimal_del,   METH_VARARGS,     del_docstring },
	{ "hitminimal_algo",  py_hitminimal_algo,  METH_VARARGS,    algo_docstring },
	{ "hitminimal_dcall", py_hitminimal_dcall, METH_VARARGS,   dcall_docstring },

	{ NULL, NULL, 0, NULL }
};

extern "C" {

// module initialization
//=============================================================================
PyMODINIT_FUNC initpyhitman(void)
{
	PyObject *m = Py_InitModule3("pyhitman", module_methods,
			module_docstring);

	if (m == NULL)
		return;
}

//
//=============================================================================
static PyObject *py_hitminimum_new(PyObject *self, PyObject *args)
{
	HitMinimum *hitman = new HitMinimum();

	if (hitman == NULL) {
		PyErr_SetString(PyExc_RuntimeError,
				"Cannot create a new hitting set enumerator.");
		return NULL;
	}

#if PY_MAJOR_VERSION < 3
	PyObject *ret = PyCObject_FromVoidPtr((void *)hitman, NULL);
#else
	PyObject *ret = PyCapsule_New((void *)hitman, NULL, NULL);
#endif

	return ret;
}

// MaxSAT-based minimal hitting set enumerator
//=============================================================================
static PyObject *py_hitminimum_get(PyObject *self, PyObject *args)
{
	PyObject *h_obj;

	if (!PyArg_ParseTuple(args, "O", &h_obj))
		return NULL;

	// get pointer to enumerator
#if PY_MAJOR_VERSION < 3
	HitMinimum *hitman = (HitMinimum *)PyCObject_AsVoidPtr(h_obj);
#else
	HitMinimum *hitman = (HitMinimum *)PyCapsule_GetPointer(h_obj, NULL);
#endif

	vector<int> hs = hitman->get();

	PyObject *hs_list = PyList_New(hs.size());
	for (size_t i = 0; i < hs.size(); ++i) {
		PyObject *hs_entry = PyInt_FromLong(hs[i]);
		PyList_SetItem(hs_list, i, hs_entry);
	}

	PyObject *ret = Py_None;

	if (hs.size())
		ret = Py_BuildValue("O", hs_list);

	Py_DECREF(hs_list);
	return ret;
}

//
//=============================================================================
static PyObject *py_hitminimum_enum(PyObject *self, PyObject *args)
{
	PyObject *h_obj;

	if (!PyArg_ParseTuple(args, "O", &h_obj))
		return NULL;

	// get pointer to enumerator
#if PY_MAJOR_VERSION < 3
	HitMinimum *hitman = (HitMinimum *)PyCObject_AsVoidPtr(h_obj);
#else
	HitMinimum *hitman = (HitMinimum *)PyCapsule_GetPointer(h_obj, NULL);
#endif

	vector<int> hs = hitman->enumerate();

	PyObject *hs_list = PyList_New(hs.size());
	for (size_t i = 0; i < hs.size(); ++i) {
		PyObject *hs_entry = PyInt_FromLong(hs[i]);
		PyList_SetItem(hs_list, i, hs_entry);
	}

	PyObject *ret = Py_None;

	if (hs.size())
		ret = Py_BuildValue("O", hs_list);

	Py_DECREF(hs_list);
	return ret;
}

//
//=============================================================================
static PyObject *py_hitminimum_hit(PyObject *self, PyObject *args)
{
	PyObject *h_obj;
	PyObject *s_obj;

	if (!PyArg_ParseTuple(args, "OO", &h_obj, &s_obj))
		return NULL;

	// get pointer to enumerator
#if PY_MAJOR_VERSION < 3
	HitMinimum *hitman = (HitMinimum *)PyCObject_AsVoidPtr(h_obj);
#else
	HitMinimum *hitman = (HitMinimum *)PyCapsule_GetPointer(h_obj, NULL);
#endif

	size_t size = (size_t)PyList_Size(s_obj);
	vector<int> to_hit((size_t)size);

	for (size_t i = 0; i < size; ++i) {
		PyObject *s_entry = PyList_GetItem(s_obj, i);
		to_hit[i] = PyInt_AsLong(s_entry);
	}

	hitman->hit(to_hit);

	PyObject *ret = Py_BuildValue("");
	return ret;
}

//
//=============================================================================
static PyObject *py_hitminimum_block(PyObject *self, PyObject *args)
{
	PyObject *h_obj;
	PyObject *s_obj;

	if (!PyArg_ParseTuple(args, "OO", &h_obj, &s_obj))
		return NULL;

	// get pointer to enumerator
#if PY_MAJOR_VERSION < 3
	HitMinimum *hitman = (HitMinimum *)PyCObject_AsVoidPtr(h_obj);
#else
	HitMinimum *hitman = (HitMinimum *)PyCapsule_GetPointer(h_obj, NULL);
#endif

	size_t size = (size_t)PyList_Size(s_obj);
	vector<int> to_block((size_t)size);

	for (size_t i = 0; i < size; ++i) {
		PyObject *s_entry = PyList_GetItem(s_obj, i);
		to_block[i] = PyInt_AsLong(s_entry);
	}

	hitman->block(to_block);

	PyObject *ret = Py_BuildValue("");
	return ret;
}

//
//=============================================================================
static PyObject *py_hitminimum_weigh(PyObject *self, PyObject *args)
{
	PyObject *h_obj;
	PyObject *w_obj;

	if (!PyArg_ParseTuple(args, "OO!", &h_obj, &PyDict_Type, &w_obj))
		return NULL;

	// get pointer to enumerator
#if PY_MAJOR_VERSION < 3
	HitMinimum *hitman = (HitMinimum *)PyCObject_AsVoidPtr(h_obj);
#else
	HitMinimum *hitman = (HitMinimum *)PyCapsule_GetPointer(h_obj, NULL);
#endif

	// weights mapping
	map<int, long> weights;

	PyObject *key, *value;
	Py_ssize_t pos = 0;

	while (PyDict_Next(w_obj, &pos, &key, &value)) {
		int el = PyInt_AsLong(key);
		long w = PyInt_AsLong(value);

		weights[el] = w;
	}

	hitman->weigh(weights);

	PyObject *ret = Py_BuildValue("");
	return ret;
}

//
//=============================================================================
static PyObject *py_hitminimum_cost(PyObject *self, PyObject *args)
{
	PyObject *h_obj;

	if (!PyArg_ParseTuple(args, "O", &h_obj))
		return NULL;

	// get pointer to enumerator
#if PY_MAJOR_VERSION < 3
	HitMinimum *hitman = (HitMinimum *)PyCObject_AsVoidPtr(h_obj);
#else
	HitMinimum *hitman = (HitMinimum *)PyCapsule_GetPointer(h_obj, NULL);
#endif

	size_t cost = hitman->cost();

	PyObject *ret = Py_BuildValue("n", (Py_ssize_t)cost);
	return ret;
}

//
//=============================================================================
static PyObject *py_hitminimum_clear(PyObject *self, PyObject *args)
{
	PyObject *h_obj;

	if (!PyArg_ParseTuple(args, "O", &h_obj))
		return NULL;

	// get pointer to enumerator
#if PY_MAJOR_VERSION < 3
	HitMinimum *hitman = (HitMinimum *)PyCObject_AsVoidPtr(h_obj);
#else
	HitMinimum *hitman = (HitMinimum *)PyCapsule_GetPointer(h_obj, NULL);
#endif

	hitman->clear();

	PyObject *ret = Py_BuildValue("");
	return ret;
}

//
//=============================================================================
static PyObject *py_hitminimum_del(PyObject *self, PyObject *args)
{
	PyObject *h_obj;

	if (!PyArg_ParseTuple(args, "O", &h_obj))
		return NULL;

	// get pointer to enumerator
#if PY_MAJOR_VERSION < 3
	HitMinimum *hitman = (HitMinimum *)PyCObject_AsVoidPtr(h_obj);
#else
	HitMinimum *hitman = (HitMinimum *)PyCapsule_GetPointer(h_obj, NULL);
#endif

	delete hitman;

	PyObject *ret = Py_BuildValue("");
	return ret;
}

//
//=============================================================================
static PyObject *py_hitminimum_trim(PyObject *self, PyObject *args)
{
	PyObject *h_obj;
	int times;

	if (!PyArg_ParseTuple(args, "Oi", &h_obj, &times))
		return NULL;

	// get pointer to enumerator
#if PY_MAJOR_VERSION < 3
	HitMinimum *hitman = (HitMinimum *)PyCObject_AsVoidPtr(h_obj);
#else
	HitMinimum *hitman = (HitMinimum *)PyCapsule_GetPointer(h_obj, NULL);
#endif

	hitman->set_param_trim(times);

	PyObject *ret = Py_BuildValue("");
	return ret;
}

//
//=============================================================================
static PyObject *py_hitminimum_1call(PyObject *self, PyObject *args)
{
	PyObject *h_obj;

	if (!PyArg_ParseTuple(args, "O", &h_obj))
		return NULL;

	// get pointer to enumerator
#if PY_MAJOR_VERSION < 3
	HitMinimum *hitman = (HitMinimum *)PyCObject_AsVoidPtr(h_obj);
#else
	HitMinimum *hitman = (HitMinimum *)PyCapsule_GetPointer(h_obj, NULL);
#endif

	hitman->set_param_1call();

	PyObject *ret = Py_BuildValue("");
	return ret;
}

// MCS-based minimal hitting set enumerator
//=============================================================================
static PyObject *py_hitminimal_new(PyObject *self, PyObject *args)
{
	HitMinimal *hitman = new HitMinimal();

	if (hitman == NULL) {
		PyErr_SetString(PyExc_RuntimeError,
				"Cannot create a new hitting set enumerator.");
		return NULL;
	}

#if PY_MAJOR_VERSION < 3
	PyObject *ret = PyCObject_FromVoidPtr((void *)hitman, NULL);
#else
	PyObject *ret = PyCapsule_New((void *)hitman, NULL, NULL);
#endif

	return ret;
}

//
//=============================================================================
static PyObject *py_hitminimal_get(PyObject *self, PyObject *args)
{
	PyObject *h_obj;

	if (!PyArg_ParseTuple(args, "O", &h_obj))
		return NULL;

	// get pointer to enumerator
#if PY_MAJOR_VERSION < 3
	HitMinimal *hitman = (HitMinimal *)PyCObject_AsVoidPtr(h_obj);
#else
	HitMinimal *hitman = (HitMinimal *)PyCapsule_GetPointer(h_obj, NULL);
#endif

	vector<int> hs = hitman->get();

	PyObject *hs_list = PyList_New(hs.size());
	for (size_t i = 0; i < hs.size(); ++i) {
		PyObject *hs_entry = PyInt_FromLong(hs[i]);
		PyList_SetItem(hs_list, i, hs_entry);
	}

	PyObject *ret = Py_None;

	if (hs.size())
		ret = Py_BuildValue("O", hs_list);

	Py_DECREF(hs_list);
	return ret;
}

//
//=============================================================================
static PyObject *py_hitminimal_enum(PyObject *self, PyObject *args)
{
	PyObject *h_obj;

	if (!PyArg_ParseTuple(args, "O", &h_obj))
		return NULL;

	// get pointer to enumerator
#if PY_MAJOR_VERSION < 3
	HitMinimal *hitman = (HitMinimal *)PyCObject_AsVoidPtr(h_obj);
#else
	HitMinimal *hitman = (HitMinimal *)PyCapsule_GetPointer(h_obj, NULL);
#endif

	vector<int> hs = hitman->enumerate();

	PyObject *hs_list = PyList_New(hs.size());
	for (size_t i = 0; i < hs.size(); ++i) {
		PyObject *hs_entry = PyInt_FromLong(hs[i]);
		PyList_SetItem(hs_list, i, hs_entry);
	}

	PyObject *ret = Py_None;

	if (hs.size())
		ret = Py_BuildValue("O", hs_list);

	Py_DECREF(hs_list);
	return ret;
}

//
//=============================================================================
static PyObject *py_hitminimal_hit(PyObject *self, PyObject *args)
{
	PyObject *h_obj;
	PyObject *s_obj;

	if (!PyArg_ParseTuple(args, "OO", &h_obj, &s_obj))
		return NULL;

	// get pointer to enumerator
#if PY_MAJOR_VERSION < 3
	HitMinimal *hitman = (HitMinimal *)PyCObject_AsVoidPtr(h_obj);
#else
	HitMinimal *hitman = (HitMinimal *)PyCapsule_GetPointer(h_obj, NULL);
#endif

	size_t size = (size_t)PyList_Size(s_obj);
	vector<int> to_hit((size_t)size);

	for (size_t i = 0; i < size; ++i) {
		PyObject *s_entry = PyList_GetItem(s_obj, i);
		to_hit[i] = PyInt_AsLong(s_entry);
	}

	hitman->hit(to_hit);

	PyObject *ret = Py_BuildValue("");
	return ret;
}

//
//=============================================================================
static PyObject *py_hitminimal_block(PyObject *self, PyObject *args)
{
	PyObject *h_obj;
	PyObject *s_obj;

	if (!PyArg_ParseTuple(args, "OO", &h_obj, &s_obj))
		return NULL;

	// get pointer to enumerator
#if PY_MAJOR_VERSION < 3
	HitMinimal *hitman = (HitMinimal *)PyCObject_AsVoidPtr(h_obj);
#else
	HitMinimal *hitman = (HitMinimal *)PyCapsule_GetPointer(h_obj, NULL);
#endif

	size_t size = (size_t)PyList_Size(s_obj);
	vector<int> to_block((size_t)size);

	for (size_t i = 0; i < size; ++i) {
		PyObject *s_entry = PyList_GetItem(s_obj, i);
		to_block[i] = PyInt_AsLong(s_entry);
	}

	hitman->block(to_block);

	PyObject *ret = Py_BuildValue("");
	return ret;
}

//
//=============================================================================
static PyObject *py_hitminimal_clear(PyObject *self, PyObject *args)
{
	PyObject *h_obj;

	if (!PyArg_ParseTuple(args, "O", &h_obj))
		return NULL;

	// get pointer to enumerator
#if PY_MAJOR_VERSION < 3
	HitMinimal *hitman = (HitMinimal *)PyCObject_AsVoidPtr(h_obj);
#else
	HitMinimal *hitman = (HitMinimal *)PyCapsule_GetPointer(h_obj, NULL);
#endif

	hitman->clear();

	PyObject *ret = Py_BuildValue("");
	return ret;
}

//
//=============================================================================
static PyObject *py_hitminimal_del(PyObject *self, PyObject *args)
{
	PyObject *h_obj;

	if (!PyArg_ParseTuple(args, "O", &h_obj))
		return NULL;

	// get pointer to enumerator
#if PY_MAJOR_VERSION < 3
	HitMinimal *hitman = (HitMinimal *)PyCObject_AsVoidPtr(h_obj);
#else
	HitMinimal *hitman = (HitMinimal *)PyCapsule_GetPointer(h_obj, NULL);
#endif

	delete hitman;

	PyObject *ret = Py_BuildValue("");
	return ret;
}

//
//=============================================================================
static PyObject *py_hitminimal_algo(PyObject *self, PyObject *args)
{
	PyObject *h_obj;
	PyObject *s_obj;

	if (!PyArg_ParseTuple(args, "OO", &h_obj, &s_obj))
		return NULL;

	// get pointer to enumerator
#if PY_MAJOR_VERSION < 3
	HitMinimal *hitman = (HitMinimal *)PyCObject_AsVoidPtr(h_obj);
#else
	HitMinimal *hitman = (HitMinimal *)PyCapsule_GetPointer(h_obj, NULL);
#endif

	string algo(PyString_AsString(s_obj));
	hitman->set_param_algo(algo);

	PyObject *ret = Py_BuildValue("");
	return ret;
}

//
//=============================================================================
static PyObject *py_hitminimal_dcall(PyObject *self, PyObject *args)
{
	PyObject *h_obj;

	if (!PyArg_ParseTuple(args, "O", &h_obj))
		return NULL;

	// get pointer to enumerator
#if PY_MAJOR_VERSION < 3
	HitMinimal *hitman = (HitMinimal *)PyCObject_AsVoidPtr(h_obj);
#else
	HitMinimal *hitman = (HitMinimal *)PyCapsule_GetPointer(h_obj, NULL);
#endif

	hitman->set_param_dcall();

	PyObject *ret = Py_BuildValue("");
	return ret;
}

}  // extern "C"
