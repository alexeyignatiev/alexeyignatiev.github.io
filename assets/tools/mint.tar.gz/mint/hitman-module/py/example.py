#!/usr/bin/env python
from hitman import HitMinimum as hitman1
from hitman import HitMinimal as hitman2

if __name__ == '__main__':
    print 'simple get/block infrastructure (MCS-based):'
    q1 = hitman2()
    q1.use_dcall()
    q1.algo('lbx')  # not necessary - LBX is used by default

    q1.hit([1, 2, 3])
    q1.hit([1, 4])
    q1.hit([5, 6, 7])

    while True:
        hs = q1.get()
        if not hs:
            break
        print hs
        q1.block(hs)

    q1.delete()

    print 'weighted enumeration mode (MaxSAT-based):'
    q2 = hitman1()
    q2.hit([1, 2, 3])
    q2.hit([1, 4])
    q2.hit([5, 6, 7])

    # only three elements are weighted: 1, 2, and 7
    wghts = {1: 5, 2: 3, 7: 4}
    q2.weigh(wghts)

    for hs in q2.enum():
        print hs, '(cost = {0})'.format(q2.cost())

    q2.delete()

    print '\'with\' constructor (MaxSAT-based):'
    with hitman1() as q3:
        q3.hit([1, 2, 3])
        q3.hit([1, 4])
        q3.hit([5, 6, 7])

        for hs in q3.enum():
            print hs

    print 'bootstrap (MaxSAT-based):'
    with hitman1(bootstrap_with=[[1, 2, 3], [1, 4], [5, 6, 7]]) as q4:
        q4.trim(5)
        q4.use_1call()
        for hs in q4.enum():
            print hs

    print 'bootstrap test (MaxSAT-based):'
    l =[[1, 2, 3, 4, 5, 7, 10, 9, 8],
        [1, 2, 3, 4, 5, 7, 10, 6, 9],
        [9, 2, 3, 4, 5, 7, 10, 6, 8],
        [1, 3, 4, 5, 9, 7, 10, 6, 8],
        [1, 2, 3, 4, 5, 9, 7, 6, 8],
        [1, 2, 3, 4, 5, 7, 10, 6, 8],
        [1, 2, 3, 4, 9, 7, 10, 6, 8],
        [1, 2, 9, 4, 5, 7, 10, 6, 8],
        [1, 2, 3, 5, 9, 7, 10, 6, 8],
        [1, 2, 3, 4, 5, 9, 10, 6, 8]]
    with hitman1(bootstrap_with=l) as q5:
        q5.trim(5)
        for hs in q5.enum():
            print hs
