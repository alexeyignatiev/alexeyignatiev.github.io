#!/usr/bin/env python
#-*- coding:utf-8 -*-
##
## hitman.py
##
##  Created on: Dec 01, 2015
##      Author: Alexey S. Ignatiev
##      E-mail: aignatiev@ciencias.ulisboa.pt
##

#
#==============================================================================
import pyhitman


#
#==============================================================================
class HitMinimum(object):
    """
        Enumerator of cardinality-minimum hitting sets.
    """

    def __init__(self, bootstrap_with=None):
        """
            Basic constructor.
        """

        self.__hitman = None
        self.new()

        if bootstrap_with:
            for to_hit in bootstrap_with:
                self.hit(to_hit)

    def __enter__(self):
        """
            'with' constructor.
        """

        return self

    def __exit__(self, exc_type, exc_value, traceback):
        """
            'with' destructor.
        """

        self.delete()
        self.__hitman = None

    def new(self):
        """
            Actual constructor of the hitting set enumerator.
        """

        if not self.__hitman:
            self.__hitman = pyhitman.hitminimum_new()

    def delete(self):
        """
            Destructor.
        """

        if self.__hitman:
            pyhitman.hitminimum_del(self.__hitman)

    def get(self):
        """
            Get a new hitting set.
        """

        if self.__hitman:
            return pyhitman.hitminimum_get(self.__hitman)

    def enum(self):
        """
            Iterate over hitting sets and return one by one.
        """

        if self.__hitman:
            done = False
            while not done:
                hs = pyhitman.hitminimum_enum(self.__hitman)

                if hs:
                    yield hs
                else:
                    done = True

    def hit(self, to_hit):
        """
            Add a new set to hit.
        """

        if self.__hitman:
            pyhitman.hitminimum_hit(self.__hitman, to_hit)

    def block(self, to_block):
        """
            Block a new set (e.g. a previously found solution).
        """

        if self.__hitman:
            pyhitman.hitminimum_block(self.__hitman, to_block)


    def weigh(self, weights):
        """
            Weigh (some) elements of the sets.
        """

        if self.__hitman:
            pyhitman.hitminimum_weigh(self.__hitman, weights)

    def clear(self):
        """
            Clear internal state of the enumerator and remove all sets to hit.
        """

        if self.__hitman:
            pyhitman.hitminimum_clear(self.__hitman)

    def cost(self):
        """
            Show current cost.
        """

        if self.__hitman:
            return pyhitman.hitminimum_cost(self.__hitman)

    def trim(self, times):
        """
            Trim unsatisfiable cores at most this number of times.
        """

        if self.__hitman:
            pyhitman.hitminimum_trim(self.__hitman, times)

    def use_1call(self):
        """
            Do at most one SAT call per hitting set.
        """

        if self.__hitman:
            pyhitman.hitminimum_1call(self.__hitman)

#
#==============================================================================
class HitMinimal(object):
    """
        Enumerator of subset-minimum hitting set.
    """

    def __init__(self, bootstrap_with=None):
        """
            Basic constructor.
        """

        self.__hitman = None
        self.new()

        if bootstrap_with:
            for to_hit in bootstrap_with:
                self.hit(to_hit)

    def __enter__(self):
        """
            'with' constructor.
        """

        return self

    def __exit__(self, exc_type, exc_value, traceback):
        """
            'with' destructor.
        """

        self.delete()
        self.__hitman = None

    def new(self):
        """
            Actual constructor of the hitting set enumerator.
        """

        if not self.__hitman:
            self.__hitman = pyhitman.hitminimal_new()

    def delete(self):
        """
            Destructor.
        """

        if self.__hitman:
            pyhitman.hitminimal_del(self.__hitman)

    def get(self):
        """
            Get a new hitting set.
        """

        if self.__hitman:
            return pyhitman.hitminimal_get(self.__hitman)

    def enum(self):
        """
            Iterate over hitting sets and return one by one.
        """

        if self.__hitman:
            done = False
            while not done:
                hs = pyhitman.hitminimal_enum(self.__hitman)

                if hs:
                    yield hs
                else:
                    done = True

    def hit(self, to_hit):
        """
            Add a new set to hit.
        """

        if self.__hitman:
            pyhitman.hitminimal_hit(self.__hitman, to_hit)

    def block(self, to_block):
        """
            Block a new set (e.g. a previously found solution).
        """

        if self.__hitman:
            pyhitman.hitminimal_block(self.__hitman, to_block)

    def clear(self):
        """
            Clear internal state of the enumerator and remove all sets to hit.
        """

        if self.__hitman:
            pyhitman.hitminimal_clear(self.__hitman)

    def algo(self, algo):
        """
            Set MCS-based algorithm for doing hitting set enumeration
            (lbx, ucd, ubs, or lopz).
        """

        if self.__hitman:
            pyhitman.hitminimal_algo(self.__hitman, algo)

    def use_dcall(self):
        """
            Use clause D checks.
        """

        if self.__hitman:
            pyhitman.hitminimal_dcall(self.__hitman)
