#!/usr/bin/env python
#-*- coding:utf-8 -*-
##
## linklib.py
##
##  Created on: Dec 22, 2016
##      Author: Alexey S. Ignatiev
##      E-mail: aignatiev@ciencias.ulisboa.pt
##

#
#==============================================================================
import os
import platform

#
#==============================================================================
if __name__ == '__main__':
    # cleaning previous configuration
    if os.path.exists('libhitman.a'):
        os.remove('libhitman.a')

    # checking platform
    if platform.system() == 'Linux':
        suffix = 'linux-x86_64'
    elif platform.system() == 'Darwin':
        suffix = 'macos-x86_64'

    # linking
    os.symlink('lib/libhitman-{0}.a'.format(suffix), 'libhitman.a')
