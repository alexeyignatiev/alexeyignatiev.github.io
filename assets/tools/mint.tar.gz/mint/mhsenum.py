#!/usr/bin/env python
#-*- coding:utf-8 -*-
##
## mhsenum.py
##
##  Created on: Dec 7, 2015
##      Author: Alessandro Previti, Alexey S. Ignatiev
##      E-mail: alessandro.previti@ucdconnect.ie, aignatiev@ciencias.ulisboa.pt
##

#
#==============================================================================
from hitman import HitMinimum

#
#==============================================================================
class MinHitEnum(HitMinimum):
    """
        Interface for HitMinimum.
    """

    def __init__(self, bootstrap_with=None):
        """
            Constructor.
        """

        super(MinHitEnum, self).__init__()

        self.vars = set()
        self.maxv = 1
        self.hmap = {}
        self.rmap = {}

        if bootstrap_with:
            for s in bootstrap_with:
                self.hit(s)

    def new_id(self, var):
        """
            Create an id for a new variable.
        """

        if var not in self.vars:
            self.vars.add(var)
            self.hmap[var] = self.maxv
            self.rmap[self.maxv] = var
            self.maxv += 1

        return self.hmap[var]

    def hit(self, set_):
        """
            Wrapper for hit(). Maps elements of the set to integers.
        """

        super(MinHitEnum, self).hit(map(lambda v: self.new_id(v), set_))

    def block(self, set_):
        """
            Wrapper for block().
        """

        super(MinHitEnum, self).block(map(lambda v: self.new_id(v), set_))

    def get(self):
        """
            Wrapper for get(). Maps back if possible.
        """

        res = super(MinHitEnum, self).get()
        return map(lambda v: self.rmap[v], res) if res else None
