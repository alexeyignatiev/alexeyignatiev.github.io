#!/usr/bin/env python
#-*- coding:utf-8 -*-
##
## mint.py
##
##  Created on: Dec 14, 2015
##      Author: Alessandro Previti, Alexey S. Ignatiev
##      E-mail: alessandro.previti@ucdconnect.ie, aignatiev@ciencias.ulisboa.pt
##

#
#==============================================================================
import getopt
import os
import sys
sys.path.append('hitman-module/py')
import warnings

from mintsolve import *
from mistral import *

#
#==============================================================================
def parse_options():
    """
        Parses command-line options.
    """

    try:
        opts, args = getopt.getopt(sys.argv[1:],
                                   'b:hmq:rs:tv',
                                   ['bootstrap=',
                                    'help',
                                    'mistral',
                                    'qsolve=',
                                    'no-reduce',
                                    'no-taut',
                                    'simplify',
                                    'solver=',
                                    'verbose'])
    except getopt.GetoptError, err:
        sys.stderr.write(str(err).capitalize() + '\n')
        usage()
        sys.exit(1)

    bootstrap_with = None
    reduce_cex = True
    no_tautology = False
    simplify = False
    use_mistral = False
    solver = 'z3'
    qsolve = 'std'
    verbose = 0

    for opt, arg in opts:
        if opt in ('-b', '--bootstrap'):
            bootstrap_with = int(arg)
        elif opt in ('-h', '--help'):
            usage()
            sys.exit(0)
        elif opt in ('-m', '--mistral'):
            use_mistral = True
        elif opt in ('-q', '--qsolve'):
            qsolve = str(arg)
        elif opt in ('-r', '--no-reduce'):
            reduce_cex = False
        elif opt == '--simplify':
            simplify = True
        elif opt in ('-s', '--solver'):
            solver = str(arg)
        elif opt in ('-t', '--no-taut'):
            no_tautology = True
        elif opt in ('-v', '--verbose'):
            verbose += 1
        else:
            assert False, 'Unhandled option: {0} {1}'.format(opt, arg)

    return bootstrap_with, reduce_cex, no_tautology, simplify, solver, \
            qsolve, use_mistral, verbose, args


#
#==============================================================================
def usage():
    """
        Prints help message.
    """

    print 'Usage: ' + os.path.basename(sys.argv[0]) + ' [options] file'
    print 'Options:'
    print '        -b, --bootstrap=<int>    Try to bootstrap algorithm with sets of a given size'
    print '                                 Available values: [0 .. n] (default = 0)'
    print '        -h, --help'
    print '        -m, --mistral            Run Mistral instead of the new algorithm'
    print '        -q, --qsolve=<string>    Method to decide quantified formulas'
    print '                                 Available values: cegar, std, z3qe (default = std)'
    print '        -r, --no-reduce          Do not reduce counterexamples'
    print '        -t, --no-taut            Do not perform tautology test'
    print '        --simplify               Simplify formula before computing an MSA'
    print '        -s, --solver=<string>    SMT solver to use'
    print '                                 Available values: cvc4, mathsat, yices, z3 (default = z3)'
    print '        -v, --verbose            Be verbose'


#
#==============================================================================
if __name__ == '__main__':
    warnings.filterwarnings('ignore', category=DeprecationWarning)
    bootstrap_with, reduce_cex, no_tautology, simplify, solver, qsolve, \
            use_mistral, verbose, files = parse_options()

    if files and files[0]:
        if use_mistral:
            msa_solver = Mistral(simplify, solver, qsolve, verbose, files[0])
        else:
            msa_solver = Mint(bootstrap_with, reduce_cex, no_tautology,
                    simplify, solver, qsolve, verbose, files[0])
        msa = msa_solver.solve()

        if msa != None:
            if msa:
                print 's MSA found'

            print 'o', len(msa)
            if verbose > 1 and msa:
                print 'v', ' '.join(msa)
        else:
            print 's UNSATISFIABLE'
    else:
        print >> sys.stderr, 'Error: not input file specified!'
