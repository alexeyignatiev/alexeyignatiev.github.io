#!/usr/bin/env python
#-*- coding:utf-8 -*-
##
## mintsolve.py
##
##  Created on: Dec 14, 2015
##      Author: Alessandro Previti, Alexey S. Ignatiev
##      E-mail: alessandro.previti@ucdconnect.ie, aignatiev@ciencias.ulisboa.pt
##

#
#==============================================================================
from mhsenum import *
import os
import pysmt.operators as op
from pysmt.smtlib.parser import SmtLibParser
from pysmt.shortcuts import Not, ForAll, is_sat, is_unsat, get_model, qelim
from qsolve import get_qmodel

#
#==============================================================================
class Mint:
    """
        Mint MSA solver class.
    """

    def __init__(self, bootstrap_with, reduce_cex, no_tautology,
            simplify, solver, qsolve, verbose, fname):
        """
            Constructor.
        """

        self.script = SmtLibParser().get_script_fname(fname)
        self.formula = self.script.get_last_formula()
        if simplify:
            self.formula = self.formula.simplify()
        self.fvars = self.formula.get_free_variables()

        self.cost = 0
        self.reduce = reduce_cex
        self.notaut = no_tautology
        self.sname = solver
        self.fname = fname
        self.verb = verbose
        self.bootstrap_with = bootstrap_with
        self.qsolve = qsolve

        if self.verb > 2:
            print 'c formula: \'{0}\''.format(self.formula)
            print ''

        if self.verb > 1:
            print 'c vars ({0}):'.format(len(self.fvars)), list(self.fvars)

    def solve(self):
        """
            This method implements Algorithm 1 in the memo.
        """

        # testing if formula is satisfiable
        fmodel = get_model(self.formula, solver_name=self.sname)
        if fmodel == None:
            return None

        if not self.notaut:
            # testing if formula is not a tautology, i.e. MSA is not []
            if is_unsat(Not(self.formula), solver_name=self.sname):
                return []

        to_hit = [self.fvars]
        if self.bootstrap_with:
            to_hit += self.bootstrap_simple()

        with MinHitEnum(bootstrap_with=to_hit) as minhs:
            while True:
                X = minhs.get()

                if self.cost < len(X):
                    self.cost = len(X)
                    print 'c cost:', self.cost

                if self.verb > 1:
                    print 'c cand:', X

                Y = self.fvars - set(X)
                if not Y:
                    # set X comprises all variables,
                    # and we already have a model for them
                    model = fmodel
                    break

                model = self.get_model_forall(Y)
                if model:
                    break

                if self.reduce and len(Y) > 1:
                    test_self = False
                    while Y:
                        to_hit = self.get_irreducible_fd(Y, test_self)
                        if not to_hit:
                            break

                        Y = Y - set(to_hit)
                        test_self = True

                        minhs.hit(to_hit)
                        if self.verb > 1:
                            print 'c coex:', to_hit
                else:
                    minhs.hit(Y)
                    if self.verb > 1:
                        print 'c coex:', list(Y)

            return [ '{0}={1}'.format(x, model[x]) for x in X ]

    def get_irreducible_ls(self, to_reduce, test_self=False):
        """
            Returns an irreducible subset of an input set. Linear search.
        """

        def var_needed(v):
            if len(to_test) > 1:
                to_test.remove(v)

                if not self.get_model_forall(to_test):
                    return False

                to_test.add(v)
                return True
            else:
                return True

        if not test_self or not self.get_model_forall(to_reduce):
            to_test = set(to_reduce)
            return filter(lambda v: var_needed(v), to_reduce)
        else:
            return None

    def get_irreducible_fd(self, to_reduce, test_self=False):
        """
            Returns an irreducible subset of an input set.
            Uses an algorithm similar to QuickXplain and FastDiag.
        """

        if not test_self or not self.get_model_forall(to_reduce):
            coex = list(to_reduce)
            filt_sz = len(coex) / 2.0

            while filt_sz >= 1:
                i = 0
                while i < len(coex):
                    to_test = coex[:i] + coex[(i + int(filt_sz)):]
                    if to_test and not self.get_model_forall(to_test):
                        # vars are not needed
                        coex = to_test
                    else:
                        # vars are needed => check the next chunk
                        i += int(filt_sz)

                # decreasing size of the set to filter
                filt_sz /= 2.0
                if filt_sz > len(coex) / 2.0:
                    # next size is too large => make it smaller
                    filt_sz = len(coex) / 2.0

            return coex
        else:
            return None

    def bootstrap_simple(self):
        """
            Detects sets to hit by trying all the combinations of the size up
            to a given parameter.
        """

        to_hit = []

        with MinHitEnum(bootstrap_with=[self.fvars]) as minhs:
            while minhs.cost() <= self.bootstrap_with:
                hs = minhs.get()
                if not hs or len(hs) > self.bootstrap_with:
                    break

                if not self.get_model_forall(hs):
                    if self.verb > 1:
                        print 'c bootstrap', hs

                    to_hit.append(hs)  # found a set to hit
                    for v in hs:
                        minhs.block([v])  # disjoint block
                else:
                    # just block previous solution (hit the rest)
                    minhs.hit(self.fvars - frozenset(hs))

        return to_hit

    def get_model_forall(self, x_univl):
        """
            Calls either pysmt.shortcuts.get_model() or get_qmodel().
        """

        if self.qsolve == 'std':
            return get_model(ForAll(x_univl, self.formula),
                    solver_name=self.sname)
        elif self.qsolve == 'z3qe':
            formula = qelim(ForAll(x_univl, self.formula))
            return get_model(formula, solver_name=self.sname)
        else:
            return get_qmodel(x_univl, self.formula, solver_name=self.sname,
                    verbose=True if self.verb > 2 else False)
